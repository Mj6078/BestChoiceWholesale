import 'core-js';
// import 'regenerator-runtime/runtime'; // papathemes-supermarket
import 'whatwg-fetch';
import objectFitImages from 'object-fit-images';

document.addEventListener('DOMContentLoaded', () => {
    objectFitImages();
});
